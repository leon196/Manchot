Please use .NET 2.0

